Outlandish Revelations - Garrick Forge WORLDGEN v3 TEST
Minecraft Java 1.20.1 / Forge 47.x / Paxi 4.0

Purpose: Fix the v2 jigsaw generator without changing successful Garrick NPC, marker, or anvil upgrade.

Changes from v2:
- Added actual downward-facing named jigsaw start block to ruin template.
- Structure definition uses size 1 and names the start anchor.
- Added a jigsaw_replacement processor to turn root block into cobblestone during jigsaw generation.
- Pool uses legacy_single_pool_element to avoid replacing surrounding terrain with air.
- Reduced max jigsaw distance from center to 32 (single 11x7x9 structure).
- Kept random_spread spacing 24 / separation 8 and the same biome tag.

Installation:
Remove v2 zip from config/paxi/datapacks. Put THIS zip there instead. Restart the game.
DO NOT load two versions of the same structure datapack at once.
For initial test, create a disposable NEW test world with structures enabled.
Before exploring, try /place structure outlandish:garrick_forge ~ ~ ~ on suitable land,
then /locate structure outlandish:garrick_forge.
Use /place template outlandish:garrick_ruin ~ ~ ~ as a diagnostic ONLY;
that command bypasses normal structure generation and will leave a jigsaw block at the anchor.

Status: Validated ZIP, JSON and NBT file encodings programmatically. NOT tested in-game.
If /place structure fails, capture latest.log and pause worldgen testing.
