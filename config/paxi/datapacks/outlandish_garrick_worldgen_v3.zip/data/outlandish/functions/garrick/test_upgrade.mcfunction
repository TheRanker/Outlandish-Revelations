# For local testing only; run near a naturally generated Garrick forge.
execute at @s as @e[type=minecraft:marker,tag=outlandish_garrick_anvil,tag=!outlandish_garrick_anvil_placed,distance=..12,sort=nearest,limit=1] at @s run function outlandish:garrick/upgrade_01
