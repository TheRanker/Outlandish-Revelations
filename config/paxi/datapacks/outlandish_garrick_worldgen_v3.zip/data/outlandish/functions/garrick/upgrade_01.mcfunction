# Called AS AND AT the nearest tagged forge marker after a completed Garrick quest.
execute if block ~ ~ ~ minecraft:air run setblock ~ ~ ~ minecraft:anvil
execute if block ~ ~ ~ minecraft:anvil run tag @s add outlandish_garrick_anvil_placed
